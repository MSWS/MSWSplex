package mc.bukkit.MSWS.MSWSplex;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NotifyCommand {
	public static void command(CommandSender sender, Command command, String label, String[] args) {
		if (!Main.config.getBoolean("Features.commands.ping")) {
			Main.notEnabled(sender);
			return;
		}
		if (!Main.config.getBoolean("Features.commands.notify")) {
			Main.notEnabled(sender);
			return;
		}
		String prefix = "&9Notify> &7";
		if (sender instanceof Player) {
			Player player = (Player) sender;
			String uuid = player.getUniqueId() + "";
			if (args.length != 1) {
				sender.sendMessage(Main.color(prefix + "/notify [chat|join]"));
			} else {
				Main.data.set("Users." + uuid + ".notify." + args[0],
						!Main.data.getBoolean("Users." + uuid + ".notify." + args[0]));
				switch (args[0].toLowerCase()) {
				case "chat":
					if (Main.data.getBoolean("Users." + uuid + ".notify." + args[0])) {
						sender.sendMessage(Main.color(prefix
								+ "You will receive notifications when someone says your username in chat."));
					} else {
						sender.sendMessage(Main.color(prefix
								+ "You will no longer receive notifications when someone says your username in chat."));
					}
					break;
				case "join":
					if (Main.data.getBoolean("Users." + uuid + ".notify." + args[0])) {
						sender.sendMessage(
								Main.color(prefix + "You will receive notifications when someone joins the server."));
					} else {
						sender.sendMessage(Main.color(prefix
								+ "You will no longer receive notifications when someone joins the server."));
					}
					break;
				default:
					sender.sendMessage(Main.color(prefix + "/notify [chat|join]"));
					Main.data.set("Users." + uuid + ".notify." + args[0], null);
					return;
				}
			}
		} else {
			sender.sendMessage(Main.color(prefix + "You must be a player."));
		}
	}
}
