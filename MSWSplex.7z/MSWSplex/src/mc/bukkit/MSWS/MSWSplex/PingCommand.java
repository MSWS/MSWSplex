package mc.bukkit.MSWS.MSWSplex;

import java.util.Date;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PingCommand {
	public static void command(CommandSender sender, Command command, String label, String[] args) {
		if (!Main.config.getBoolean("Features.commands.ping")) {
			Main.notEnabled(sender);
			return;
		}
		String rank = "owner";
		if (sender instanceof Player)
			rank = Main.getRankID(((Player) sender).getUniqueId());
		String prefix = "&9Ping> &7";
		Date date = new Date(Main.startTime);
		long mils = System.currentTimeMillis() - Main.startTime;
		if (Main.ranks.getInt(rank + ".rank") >= 16 && sender instanceof Player) {
			sender.sendMessage(Main.color("&9Sever status:"));
			sender.sendMessage(Main.color("&6Your ping: &7" + Main.getPing((Player) sender)));
			sender.sendMessage(Main.color("&6Last reload: &7" + date));
			sender.sendMessage(Main.color("&6Uptime: &7" + TimeManagement.getTime(mils)));
		} else {
			sender.sendMessage(Main.color(prefix + "PONG!"));
		}
	}
}
